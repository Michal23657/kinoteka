--zapytanie1
SELECT id_filmu, tytul, rok_produkcji, czas_trwania FROM filmy WHERE czas_trwania >= 100;


--zapytanie2
SELECT imie, nazwisko, plik_awatara FROM aktorzy WHERE id_aktora = 3:


--zapytanie3
SELECT * FROM aktorzy ORDER BY nazwisko ASC, imie ASC;


--zapytanie4
SELECT filmy.id_filmu, filmy.tytul, filmy.rok_produkcji FROM filmy JOIN filmy_aktorzy 
ON filmy.id_filmu = filmy_aktorzy.id_filmu WHERE filmy_aktorzy.id_aktora = 3;

--zapytanie5
SELECT aktorzy.id_aktora, COUNT(filmy_aktorzy.id_filmu) AS liczba_filmow FROM aktorzy
LEFT JOIN filmy_aktorzy ON aktorzy.id_aktora = filmy_aktorzy.id_aktora GROUP BY aktorzy.id_aktora;





































