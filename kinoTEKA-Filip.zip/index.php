
<?php
$connection = mysqli_connect("localhost", "root", "", "kino");
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Lista aktorów | KinoTEKA</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <header class="naglowkowy1">
        <h2><a href="index.php">KinoTEKA</a></h2>
    </header>
    <header class="naglowkowy2">
        <p><em>W naszej bazie znajdują się najlepsi aktorzy</em></p>
    </header>
    <main>
        <h1>Najlepsi aktorzy tylko w naszym kinie</h1>
        <div id="actors">
            <?php
            $query = "SELECT * FROM aktorzy ORDER BY nazwisko, imie;";
            $result = mysqli_query($connection, $query);
            while ($row = mysqli_fetch_row($result)) {
                echo "<a href='aktorzy.php?id=$row[0]'>";
                echo "<div class='actor'>";
                echo "<img src='$row[4]' alt='$row[1] $row[2]' title='$row[1] $row[2]'>";
                echo "<p>$row[1] $row[2]</p>";
                echo "</div>";
                echo "</a>";
            }
            ?>
        </div>
    </main>
    <footer class="stopka">
        <p>Autor: <b>Filip</b></p>
    </footer>
    <?php
    mysqli_close($connection);
    ?>
</body>
</html>
