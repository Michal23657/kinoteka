<?php
$connection = mysqli_connect("localhost", "root", "", "kino");
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Informacje o aktorze | KinoTEKA</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <header class="naglowkowy1">
        <h2><a href="index.php">KinoTEKA</a></h2>
    </header>
    <header class="naglowkowy2">
        <p><em>W naszej bazie znajdują się najlepsi aktorzy</em></p>
    </header>
    <main class="glowny">
        
        <?php
            $id = $_GET["id"];
            $query = "SELECT imie, nazwisko, plik_awatara FROM aktorzy WHERE id_aktora = $id;";
            $result = mysqli_query($connection, $query);
            $row = mysqli_fetch_row($result);
            if($row){
                echo "<div class='actor-profile'>";
                echo "<img src='$row[2]' alt='$row[0] $row[1]' title='$row[0] $row[1]'>";
                echo "<h1>$row[0] $row[1]</h1>";
                echo "</div>";
            }
            
            if($row){
                $query = "SELECT filmy.id_filmu, tytul, rok_produkcji FROM filmy JOIN filmy_aktorzy ON filmy.id_filmu = filmy_aktorzy.id_filmu 
                WHERE filmy_aktorzy.id_aktora = $id;";
                $result = mysqli_query($connection, $query);
                $count = mysqli_num_rows($result);
                if($count == 0){
                    echo "<p>$row[0] nie znajduje się na listach obsady znanych nam produkcji</p>";
                }
                else{
                    echo "<p>$row[0]znajduje się na listach obsady $count znanych nam produkcji</p>";
                }
            }

        ?>
    </main>
    <footer class="stopka">
        <p>Autor: <b>Filip</b></p>
    </footer>
</body>
</html>
